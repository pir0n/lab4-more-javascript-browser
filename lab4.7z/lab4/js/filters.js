//Filters definition

//get the references to the filter links

const all = document.getElementById("filter-all");
const important = document.getElementById("filter-important");
const today = document.getElementById("filter-today");
const week = document.getElementById("filter-week");
const private = document.getElementById("filter-private");
const shared = document.getElementById("filter-shared");
const filterTitle = document.getElementById("filter-title");
//set the callbacks

all.addEventListener('click', event => {
    all.classList.add('active');
    important.classList.remove('active');
    today.classList.remove('active');
    week.classList.remove('active');
    private.classList.remove('active');
    shared.classList.remove('active');
    filterTitle.innerText = "All";
    
    clearTasks();
    createAllTasks();
});
    
important.addEventListener('click', event => {
    all.classList.remove('active');
    important.classList.add('active');
    today.classList.remove('active');
    week.classList.remove('active');
    private.classList.remove('active');
    shared.classList.remove('active');
    filterTitle.innerText = "Important";

    clearTasks();
    const taskList = document.getElementById("taskList");

    for(const task of tasks){
        if(task.important){
            const taskNode = createTaskNode(task);
            taskList.appendChild(taskNode);
        }
    }
});
    
today.addEventListener('click', event => {
    all.classList.remove('active');
    important.classList.remove('active');
    today.classList.add('active');
    week.classList.remove('active');
    private.classList.remove('active');
    shared.classList.remove('active');
    filterTitle.innerText = "Today";

    clearTasks();
    const taskList = document.getElementById("taskList");

    for(const task of tasks){
        if(isToday(task.deadline)){
            const taskNode = createTaskNode(task);
            taskList.appendChild(taskNode);
        }
    }
    
});
    
week.addEventListener('click', event => {
    all.classList.remove('active');
    important.classList.remove('active');
    today.classList.remove('active');
    week.classList.add('active');
    private.classList.remove('active');
    shared.classList.remove('active');
    filterTitle.innerText = "Next 7 Days";

    clearTasks();
    const taskList = document.getElementById("taskList");
        
    for(const task of tasks){
        if(isNextWeek(task.deadline)){
            const taskNode = createTaskNode(task);
            taskList.appendChild(taskNode);
        }
    }
    
});
    
private.addEventListener('click', event => {
    all.classList.remove('active');
    important.classList.remove('active');
    today.classList.remove('active');
    week.classList.remove('active');
    private.classList.add('active');
    shared.classList.remove('active');
    filterTitle.innerText = "Private";

    clearTasks();
    const taskList = document.getElementById("taskList");
        
    for(const task of tasks){
        if(task.private){
            const taskNode = createTaskNode(task);
            taskList.appendChild(taskNode);
        }
    }
    
});
    
shared.addEventListener('click', event => {
    all.classList.remove('active');
    important.classList.remove('active');
    today.classList.remove('active');
    week.classList.remove('active');
    private.classList.remove('active');
    shared.classList.add('active');
    filterTitle.innerText = "Shared With...";

    clearTasks();
    const taskList = document.getElementById("taskList");
        
    for(const task of tasks){
        if(!task.private){
            const taskNode = createTaskNode(task);
            taskList.appendChild(taskNode);
        }
    }
});